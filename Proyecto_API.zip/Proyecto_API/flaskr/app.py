from flaskr import create_app
from .modelos import db, Cancion, Usuario, Album, Medio

app = create_app('default')
app_context = app.app_context()
app_context.push()

db.init_app(app)
db.create_all()

with app.app_context():
    c = Cancion(titulo='Prueba', minutos=2, segundos=25, interprete='Mario')
    db.session.add(c)
    db.session.commit()
    print(Cancion.query.all())

with app.app_context():
    a = Album(id=10, titulo='Luis', ano=2023, descripcion="ninguna", medio="ninguno")
    db.session.add(a)
    db.session.commit()
    print(Album.query.all())

with app.app_context():
    u = Usuario(id=12, nombre_usuario='Luis', contrasena='123')
    db.session.add(u)
    db.session.commit()
    print(Usuario.query.all())

with app.app_context():
    m = Medio(id=12, disco='ultimo', casete='nuevo', cd="nuevo")
    db.session.add(m)
    db.session.commit()
    print(Medio.query.all())

