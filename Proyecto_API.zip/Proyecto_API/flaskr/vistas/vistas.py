from flask_restful import Resource
from ..modelos import db, cancion, CancionShema
from flask import request

cancion_shema = CancionShema()

class VistaCanciones(Resource):
    def get(self):
        return [cancion_shema.dump(Cancion) for Cancion in Cancion.query.all()]

    def post(self):
        nueva_cancion = Cancion(titulo=request.json['titulo'],\
                                minutos=request.json['minutos'],\
                                segundos=request.json['segundos'],\
                                interprete=request.json['interprete'])
        db.session.add(nueva_cancion)
        db.session.commit()
        return cancion_shema.dump(nueva_cancion)

class VistaCancion(Resource)

    def get(self,id_cancion):
        return cancion_shema.dump(Cancion.query.get_or_404(id_cancion))

    def put(self, id_cancion):
        cancion = cancion.query.get_or_404(id_cancion)
        cancion.titulo = request.json.get('titulo', cancion.titulo)
        cancion.minutos = request.json.get('minutos', cancion.minutos)
        cancion.segundos = request.json.get('segundos', cancion.segundos)
        cancion.interprete = request.json.get('interprete',cancion.interprete)
        db.session.commit()
        return cancion_shema.dump(cancion)

    def __delete__(self, id_cancion):
        cancion = Cancion.query.get_or_404(id_cancion)
        db.session.delete(cancion)
        db.session.commit()
        return 'operacion exitosa', 204


